-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 18, 2024 at 11:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `region` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `pricemax` int(255) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `facility` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`id`, `name`, `region`, `city`, `price`, `pricemax`, `description`, `facility`, `img`) VALUES
(89, 'La Tua', 'greater-accra', 'Accra', 1000, 2000, 'Good', 'everything', '4_orea hotel pyramida.jpg'),
(90, 'Twin Hotel', 'volta', 'Alfao', 5000, 7500, 'Quality', 'Everything', '20-Pictures-From-the-Plaza-Hotel-in-New-York-City-title.jpg'),
(91, 'Star Hotel', 'greater-accra', 'Accra', 1200, 1500, 'Good', 'All', '0021-40683.jpg'),
(92, 'Oak View', 'ashanti', 'Kumasi', 800, 3500, 'description ', 'facilities', '45194655-hotel-images.jpg'),
(93, 'Kempinski Hotel Gold Coast City Accra', 'greater-accra', 'Accra', 3000, 7000, 'Nestled in the vibrant heart of Accra, Kempinski Gold Coast offers an unparalleled blend of luxury and African hospitality. Whether you\\\'re here for business or leisure, this 5-star hotel provides a sanctuary amidst the bustling city.', 'Free Wi-Fi, Infinity Pool, World-class Spa, Rooftop Bar, Fine Dining Restaurant, Business Center, Fitness Gym, Art Gallery, Shopping Arcade, Chauffeur Service.', '1.jpg'),
(94, 'Golden Tulip Kumasi City', 'ashanti', 'Kumasi', 1200, 2500, 'Located in the historical capital of the Ashanti Kingdom, Golden Tulip Kumasi combines modern amenities with a touch of local culture. Its lush gardens and exquisite rooms make for a serene stay. ', 'Free Wi-Fi, Outdoor Pool, Tennis Court, On-site Casino, Fitness Center, African Fusion Restaurant, 24-Hour Room Service, Conference Facilities, Shopping Outlets, Kids\\\' Play Area.', '2.jpg'),
(95, 'Best Western Plus Atlantic Hotel', 'western', 'Takoradi', 1100, 2200, 'Overlooking the stunning coastline of Takoradi, Best Western Plus Atlantic offers a seamless mix of ocean views and contemporary luxury. Perfect for beach lovers and business travelers alike.', 'Beach Access, Oceanview Pool, Seafood Restaurant, Poolside Bar, Spa & Wellness Center, Free Wi-Fi, Private Beach Cabanas, Live Entertainment, Meeting Rooms, Boat Tours.', '3.jpg'),
(96, 'Ridge Royal Hotel', 'central', 'Cape Coast', 800, 1500, 'Situated near the historical landmarks of Cape Coast, Ridge Royal Hotel offers a perfect getaway for history enthusiasts and leisure travelers. Enjoy panoramic views and rich cultural experiences.', ' Cultural Tour Guides, Outdoor Pool, Fitness Center, Free Wi-Fi, Oceanfront Restaurant, Rooftop Terrace, Yoga Studio, Shuttle Service to Elmina Castle, Kids\\\' Adventure Zone, Nature Walks.', '4.jpg'),
(97, 'Royal Senchi Hotel', 'eastern', 'Akosombo', 2000, 4500, 'Perched on the banks of the Volta River, Royal Senchi offers an eco-luxury experience like no other. Ideal for those seeking relaxation and scenic beauty, this hotel is an oasis of calm.', 'River Cruise, Eco-Friendly Spa, Infinity Pool, Outdoor Dining by the River, Adventure Sports (kayaking, hiking), Bird Watching Tours, Tennis Court, Free Wi-Fi, Local Craft Market, Sunset Viewing Deck.', '5.jpg'),
(98, 'Mole Motel - Mole National Park', 'northern', 'Damongo', 500, 1000, 'Nestled inside Ghana’s largest wildlife park, Mole Motel is the perfect retreat for nature lovers and adventurers. Witness wildlife in its natural habitat while enjoying the comforts of a cozy stay.', 'Guided Safari Tours, Wildlife Viewing Deck, Outdoor Pool, Free Wi-Fi, African-Themed Restaurant, Nature Walks, Bird Watching Expeditions, Stargazing Area, Traditional Dance Performances, Campfire Evenings.', '6.jpg'),
(100, 'Blue Hill Hotel', 'upper-west', 'Wa', 400, 800, 'Located in the serene city of Wa, Blue Hill Hotel offers a quiet and relaxing environment with modern amenities. Ideal for both business travelers and those looking to unwind in northern Ghana.', 'Free Wi-Fi, Outdoor Pool, Rooftop Bar, Conference Rooms, Spa Services, Local and International Restaurant, Bike Rentals, Quiet Garden Area, Library, Evening Bonfires.', '8.jpg'),
(101, 'Volta Serene Hotel', 'volta', 'Ho', 800, 1600, 'Nestled in the picturesque hills of the Volta Region, Volta Serene offers breathtaking views and luxurious accommodations. It\\\'s the perfect destination for travelers looking for adventure and relaxation.', 'Hiking Trails, Infinity Pool, Mountain-View Restaurant, Free Wi-Fi, Gym, Adventure Sports (rock climbing, zip-lining), Yoga Classes, Art Exhibitions, Kids\\\' Club, Nature Photography Tours.', '9.jpg'),
(102, 'Techiman Holy Family Hotel', 'bono-east', 'Techiman', 300, 600, 'Techiman Holy Family Hotel offers the perfect blend of comfort and convenience for travelers passing through Bono East. Experience local culture with modern comforts during your stay.', 'Free Wi-Fi, Outdoor Pool, Religious Heritage Tours, Local Dining Restaurant, Outdoor Lounge, Gym, Guided Market Tours, Quiet Garden, Shuttle Service, Art and Craft Workshops.', '11.jpg'),
(103, 'Hills and Rivers Hotel', 'ahafo', 'Goaso', 350, 700, 'Escape to nature at Hills and Rivers Hotel, where the lush landscapes of Ahafo await. Enjoy breathtaking views and a peaceful retreat in one of Ghana’s greenest regions.', 'Nature Hikes, River Rafting, Free Wi-Fi, Outdoor Pool, Local and International Restaurant, Yoga and Wellness Center, Bird Watching, Private Picnic Areas, Spa Services, Bonfire Evenings.', '12.jpg'),
(104, 'Sefwi Wiawso Lodge', 'western-north', 'Sefwi Wiawso', 350, 750, 'A hidden gem in Western North, Sefwi Wiawso Lodge offers rustic charm and modern amenities. Perfect for those seeking an off-the-beaten-path adventure. ', 'Guided Cocoa Farm Tours, Free Wi-Fi, Outdoor Pool, Local Cuisine Restaurant, Traditional Craft Market, Bike Rentals, Hiking Trails, Cultural Workshops, Evening Performances, Community Outreach Programs.', '13.jpg'),
(105, 'Wli Water Heights Hotel', 'oti', 'Wli Afegame', 400, 750, 'Tucked away near the famous Wli Waterfalls, Wli Water Heights Hotel provides a serene retreat for nature lovers and adventurers alike. Experience the beauty of Ghana’s tallest waterfall up close.', 'Guided Waterfall Hikes, Free Wi-Fi, Outdoor Pool, Jungle Walks, Adventure Sports (zip-lining, abseiling), Local Food Experience, Nature Photography Workshops, Outdoor Dining, Evening Fireside Chats, Eco-Friendly Tours.', '14.jpg'),
(106, 'Safari Lodge', 'savannah', 'Damongo', 400, 950, 'Enjoy an authentic African safari experience at Safari Lodge, located near the pristine wilderness of Mole National Park. Ideal for adventure seekers and nature enthusiasts.', 'Safari Tours, Wildlife Viewing Platforms, Outdoor Pool, Traditional African Restaurant, Campfire Dining, Free Wi-Fi, Bird Watching Tours, Nature Photography Classes, Guided Nature Walks, Cultural Dance Shows.', '15.jpg'),
(107, 'GILLBT Guest House', 'north-east', 'Nalerigu', 400, 650, 'A cozy guest house located in the peaceful town of Nalerigu, GILLBT offers affordable comfort with a personal touch. Perfect for visitors to the northern regions.', 'Free Wi-Fi, Traditional Meals, Garden Area, Guided Village Tours, Quiet Lounge, Cultural History Talks, Community Outreach Programs, Book Exchange, Bike Rentals, Evening Storytelling Sessions.', '16.jpg'),
(108, 'Akayet Hotel', 'upper-east', 'Bolgatanga', 700, 1200, 'Experience northern Ghana in style at Akayet Hotel, a blend of modernity and culture. This hotel offers a unique atmosphere for travelers wanting to explore the rich traditions of the Upper East Region.', 'Free Wi-Fi, Outdoor Pool, Cultural Heritage Tours, Local Cuisine Restaurant, Craft Shopping Arcade, Gym, Traditional Music Performances, On-site Coffee Shop, Meeting & Event Spaces, Nature Trails.', '7.jpg'),
(109, 'Eusbett Hotel', 'bono', 'Sunyani', 600, 1300, 'As Bono Region’s premier hotel, Eusbett Hotel is an ideal choice for comfort, luxury, and business services. Enjoy the tranquility of Sunyani while staying at this top-tier hotel.', 'Free Wi-Fi, Outdoor Pool, Spa & Wellness Center, Business Lounge, International Cuisine Restaurant, Fitness Center, Golf Course Access, Conference Facilities, 24-Hour Room Service, City Tour Packages.', '10.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `reviews` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `hotel_id`, `username`, `rating`, `reviews`) VALUES
(21, 89, 2, 4, 'nice place to be at');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `travel_preferences` text DEFAULT NULL,
  `frequent_locations` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `dob`, `gender`, `travel_preferences`, `frequent_locations`, `phone`) VALUES
(1, 'admin', 'admin@gmail.com', 'adminpass', '2014-07-02', 'male', 'i prefer nice', 'accra', '1234567896'),
(2, 'George', 'george@gmail.com', 'georgepass', '2000-07-05', 'male', 'qwertyu', 'Accra', '123456'),
(3, 'Baiden', 'baiden@gmail.com', 'baidenpass', '1997-07-02', 'male', 'qwerty', 'Accra', '123456'),
(4, 'David Armah', 'david@gmail.com', 'davidpass', '1999-07-01', 'male', 'qwertyu', 'Tema', '67890');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `id` int(11) NOT NULL,
  `region` varchar(50) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `guests` int(11) NOT NULL,
  `room_preferences` text DEFAULT NULL,
  `budget` decimal(10,2) NOT NULL,
  `price_range` varchar(255) DEFAULT NULL,
  `travel_purpose` varchar(255) DEFAULT NULL,
  `activities` text DEFAULT NULL,
  `amenities` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hotel_id` (`hotel_id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`username`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
