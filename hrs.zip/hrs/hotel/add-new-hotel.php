<?php include 'header.php';
include 'sidebar.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);?>


<div class="container my-5">
 
    <!-- Form to add new hotel -->

    <form class="hoteform" method="POST" action='addnewhotel.php' enctype="multipart/form-data">
        <h2>Add new hotel </h2>
        <br>
        <label for="name">Hotel Name:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Hotel name" required><br/>
        
        <label for="price">Price:</label>
        <input type="text" class="form-control" id="price" name="price" placeholder="Minimum Price" required><br/>
        
        <label for="pricemax">Price Max:</label>
        <input type="text" class="form-control" id="pricemax" name="pricemax" placeholder="Maximum Price" required><br/>
        
        <label for="description">Description:</label>
        <textarea id="description" class="form-control" name="description" placeholder="Hotel description" required></textarea><br/>
        
        <label for="facility">Facility:</label>
        <textarea id="facility" class="form-control" name="facility" placeholder="Facilities" required></textarea><br/>
        
        <label for="region">Region:</label>
        <select id="region" name="region" required>
            <option value="">Select a region</option>
            <option value="greater-accra">Greater Accra</option>
            <option value="ashanti">Ashanti</option>
            <option value="central">Central</option>
            <option value="eastern">Eastern</option>
            <option value="northern">Northern</option>
            <option value="upper-east">Upper East</option>
            <option value="upper-west">Upper West</option>
            <option value="volta">Volta</option>
            <option value="western">Western</option>
            <option value="western-north">Western North</option>
            <option value="savannah">Savannah</option>
            <option value="oti">Oti</option>
            <option value="brong-ahafo">Brong-Ahafo</option>
            <option value="ahafo">Ahafo</option>
            <option value="bono-east">Bono East</option>
            <option value="bono">Bono</option>
            <option value="north-east">North East</option>
        </select><br/>

        <label for="city">City:</label>
        <input type="text" class="form-control" id="city" name="city" placeholder="City" required><br/>
        
        <label for="file">Hotel Image:</label>
        <input type="file" class="form-control" value="Upload Image" id="fileToUpload" name="file" required><br/>
        
        <input type="submit" class="btn btn-primary btn-block" value="Submit">
    </form>

    <!-- End of add new hotel form -->



</div>

<?php include 'footer.php' ?>