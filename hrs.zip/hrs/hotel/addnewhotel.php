<?php
session_start();
require 'mysql_connect.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize user input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $pricemax = mysqli_real_escape_string($conn, $_POST['pricemax']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $facility = mysqli_real_escape_string($conn, $_POST['facility']);
    $region = mysqli_real_escape_string($conn, $_POST['region']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    
    // Generate the name slug
    $name_slug = preg_replace('#[ -]+#', '-', strtolower($name));
    
    // Set target directory for image upload
    $target_dir = "assets/hotel_img/" . strtolower($region) . "/" . strtolower($city) . "/" . $name_slug;
    if (!file_exists($target_dir)) {
        if (!mkdir($target_dir, 0777, true)) {
            die("Failed to create directories...");
        }
    }

    // Handle file upload
    $img = $_FILES['file']['name'];
    $target_file = $target_dir . "/" . basename($img);
    
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO hotel (name, price, pricemax, description, facility, region, city, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        }

        $bind = $stmt->bind_param("ssssssss", $name, $price, $pricemax, $description, $facility, $region, $city, $img);
        if ($bind === false) {
            die("Bind failed: (" . $stmt->errno . ") " . $stmt->error);
        }
        
        // Execute the statement
        if ($stmt->execute()) {
            header("Location: all-hotel.php");
            exit();
        } else {
            echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
} else {
    echo "Invalid request method.";
}

// Close the database connection
$conn->close();
?>
