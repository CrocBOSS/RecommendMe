<?php include 'header.php' ?>

<?php include 'sidebar.php' ?>

<div style="width:80%;background:whitesmoke;height:1000px;">
	 
</div>

<?php include 'footer.php' ?>