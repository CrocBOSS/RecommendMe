<footer>
    <p>&copy; 2024 Hotel Recommendation System</p>
</footer>
</body>
</html>