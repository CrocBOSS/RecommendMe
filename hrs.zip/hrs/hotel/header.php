<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>RecommendMe</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/styles.css">

  <!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

  <!-- Bootstrap JavaScript -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

  <!-- jQuery UI -->
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="//jqueryui.com/resources/demos/style.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
  <!-- Datepicker initialization script -->
  <script>
    $( function() {
      $( ".datepicker" ).datepicker({
        changeMonth: true,
        changeYear: true
      });
    });
  </script>

  <style>
    .navbar {
      font-size: 18px;
      background-color: #004080; /* Change this to any color you like */
    }
    .navbar-brand, .nav-link {
      color: #fff !important;
    }
    .navbar-brand:hover, .nav-link:hover {
      color: #ddd !important;
    }
    body {
      font-family: 'Roboto', sans-serif;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#">Hotel Recommendation System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <?php if(!isset($_SESSION['is_logged_in'])) { 
        $_SESSION['is_logged_in'] = "0";
      } ?>

      <?php if($_SESSION['is_logged_in'] == "true") { ?>
        <?php if($_SESSION['userid'] == '1') { ?>
          <li class="nav-item">
            <a class="nav-link" href="all-hotel.php">Admin Panel</a>
          </li>
        <?php } ?>

        <li class="nav-item">
          <a class="nav-link" href="login.php?logout=true">Logout</a>
        </li>
      <?php } else { ?>
        <li class="nav-item">
          <a class="nav-link" href="register.php">Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
        </li>
      <?php } ?>

      <li class="nav-item">
        <a class="nav-link" href="recommend_form.php">Recommend</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
    </ul>
  </div>
</nav>

<!-- Your body content here -->

