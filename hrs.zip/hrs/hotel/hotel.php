<?php include 'header.php'; ?>
<?php require 'mysql_connect.php'; ?>

<?php 
$id = $_GET['id'];

/* Fetching data from database based on selected id */
$sql = "SELECT * FROM hotel WHERE id=" . $id;
$result = $conn->query($sql);

if ($result->num_rows > 0) { 
    $row = $result->fetch_assoc();
    $name_slug = preg_replace('#[ -]+#', '-', strtolower($row['name']));
    $region_slug = strtolower($row['region']);
    $city_slug = strtolower($row['city']);
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 text-center">
            <img src="assets/hotel_img/<?php echo $region_slug; ?>/<?php echo $city_slug; ?>/<?php echo $name_slug; ?>/<?php echo $row['img']; ?>" class="img-fluid" alt="<?php echo $row['name']; ?>"/>
        </div>
        <div class="col-md-6">
            <h2><?php echo $row['name']; ?></h2>
            <p class="text-muted">Location: <?php echo ucfirst($row['city']); ?>, <?php echo ucfirst($row['region']); ?></p>
            <p><strong>Price:</strong> Under ₵<?php echo $row['price']; ?></p>
            <p><strong>Description:</strong> <?php echo $row['description']; ?></p>
            <p><strong>Facility:</strong> <?php echo $row['facility']; ?></p>
        </div>
    </div>

    <?php if ($_SESSION['is_logged_in'] == "true") { ?>
    <div class="row mt-4">
        <div class="col-md-12">
            <h4>Write a review about the hotel</h4>
            <form class="reviewform" method="POST" action="review.php" onsubmit="return validateForm()">
                <div class="form-group">
                    <label>Rate this Hotel:</label>
                    <div>
                        <input class="star star-5" id="star-5" type="radio" name="rating" value="5"/>
                        <label class="star star-5" for="star-5"></label>
                        <input class="star star-4" id="star-4" type="radio" name="rating" value="4"/>
                        <label class="star star-4" for="star-4"></label>
                        <input class="star star-3" id="star-3" type="radio" name="rating" value="3"/>
                        <label class="star star-3" for="star-3"></label>
                        <input class="star star-2" id="star-2" type="radio" name="rating" value="2"/>
                        <label class="star star-2" for="star-2"></label>
                        <input class="star star-1" id="star-1" type="radio" name="rating" value="1"/>
                        <label class="star star-1" for="star-1"></label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="hidden" name="hotelid" value="<?php echo $id; ?>"/>
                    <input type="hidden" name="username" value="<?php echo $_SESSION['userid']; ?>"/>
                    <textarea class="form-control" rows="4" name="reviews" placeholder="Write something (optional)"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <?php } ?>

    <?php
    /* Fetching reviews based on id */
    $hotel_id = $row['id'];
    $sql1 = "SELECT * FROM reviews WHERE hotel_id='$hotel_id' ORDER BY id DESC";
    $result1 = $conn->query($sql1) or die($conn->error); 
    
    if ($result1->num_rows > 0) { ?>
        <div class="row mt-4">
            <div class="col-md-12">
                <h2>Reviews by users:</h2>
                <?php while ($row1 = $result1->fetch_assoc()) {
                    $userId = $row1['username']; 
                    $sql2 = "SELECT name FROM users WHERE id='$userId'";
                    $result2 = $conn->query($sql2);
                    $row2 = $result2->fetch_assoc();
                    $username = $row2['name'];
                ?>
                    <div class="media mb-4">
                        <div class="media-body">
                            <h5 class="mt-0">
                                <?php for ($j = 0; $j < $row1['rating']; $j++) { ?>
                                    <i class="fa fa-star text-warning"></i>
                                <?php } ?>
                            </h5>
                            <p><?php echo $row1['reviews']; ?></p>
                            <p class="text-muted">User: <b><?php echo ucwords($username); ?></b></p>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
        <?php } else { ?>
        <div class="row mt-4">
            <div class="col-md-12">
                <h2 class="text-danger">No reviews available</h2>
            </div>
        </div>
        <?php } ?>
        </div>
        
        <script>
             function validateForm() {
        var rating = document.querySelector('input[name="rating"]:checked');
        if (!rating) {
            alert("Please select a rating.");
            return false;
        }
        return true;
    }
        </script>

<?php
/* Similar hotels based on location and price selected by user */
$region = strtolower($row['region']);
$city = strtolower($row['city']);
$sugg_price = $row['price'];
$sql = "SELECT * FROM hotel WHERE id!='$id' AND region='$region' AND city='$city' AND price < '$sugg_price' LIMIT 5";
$result = $conn->query($sql) or die($conn->error);  // Error handling added

if ($result->num_rows > 0) {
?>
<div class="container mt-5">
    <h2>Customers also viewed:</h2>
    <div class="row">
        <?php while ($row = $result->fetch_assoc()) {   
            $name_slug = preg_replace('#[ -]+#', '-', strtolower($row['name']));
            $hotel_id = $row['id'];
            $sql3 = "SELECT rating FROM reviews WHERE hotel_id='$hotel_id' LIMIT 5";
            $result3 = $conn->query($sql3);
            $sum = 0;
            $usercount = 0;
            while ($row3 = $result3->fetch_assoc()) {
                $sum += ($row3['rating']);
                $usercount++;
            }

            if ($usercount == '0') {
                $usercount = 1;
            }
            $averating = round($sum / $usercount);
        ?>
        <div class="col-md-4">
            <div class="card mb-4">
                <img src="assets/hotel_img/<?php echo $region_slug; ?>/<?php echo $city_slug; ?>/<?php echo $name_slug; ?>/<?php echo $row['img']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>"/>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['name']; ?></h5>
                    <p class="card-text">Price: Under ₵<?php echo $row['price']; ?></p>
                    <p>Rating:
                        <?php for ($i = 0; $i < $averating; $i++) { ?>
                            <i class="fa fa-star text-warning"></i>
                        <?php } ?>
                    </p>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php } ?>
<?php include 'footer.php'; ?>
<?php } else { ?>
<div class="container mt-5">
    <h2 class="text-danger">Hotel not found</h2>
</div>
<?php } ?>
