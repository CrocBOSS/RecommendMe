<?php include 'header.php' ?>
<?php require 'mysql_connect.php'; ?>
<?php include 'sidebar.php' ?>


<!-- Updating hotel information -->

<?php $id=$_GET['id'];
		$sql = "SELECT * FROM hotel where id=".$id;
		$result = $conn->query($sql);
		if ($result->num_rows > 0) { 
		$row = $result->fetch_assoc();
	}

?>






<div style="width:80%;background:whitesmoke;height:1000px;padding:10px 200px;">

<form class="hoteform" method="POST" action='updatehotel.php' enctype="multipart/form-data">
	<h2>Edit hotel details</h2>
	<br>
	<input type="hidden" name="id"  value='<?php echo $row['id'];?>'/><br/>

    <label for="name">Hotel Name:</label>
    <input type="text" id="name" name="name" placeholder="Hotel name" value='<?php echo $row['name'];?>' required><br/>
    
    <label for="price">Price:</label>
    <input type="text" id="price" name="price" placeholder="Minimum Price" value='<?php echo $row['price'];?>' required><br/>
    
    <label for="pricemax">Price Max:</label>
    <input type="text" id="pricemax" name="pricemax" placeholder="Maximum Price" value='<?php echo $row['pricemax'];?>' required><br/>
    
    <label for="description">Description:</label>
    <textarea id="description" name="description" placeholder="Hotel description" value='<?php echo $row['description'];?>' required></textarea><br/>
    
    <label for="facility">Facility:</label>
    <textarea id="facility" name="facility" placeholder="Facilities" value='<?php echo $row['facility'];?>' required></textarea><br/>
    
    <label for="location">Location:</label>
    <input type="text" id="location" name="location" placeholder="location" value='<?php echo $row['location'];?>' required><br/>
    
    <label for="file">Hotel Image:</label>
    <input type="file" value="Upload Image" id="fileToUpload" name="file" required><br/>
    
    <input type="submit" value="Submit">
</form>




</div>

<?php include 'footer.php' ?>