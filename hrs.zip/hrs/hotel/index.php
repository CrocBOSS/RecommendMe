<?php include 'header.php'; ?>
<?php require 'mysql_connect.php'; ?>

<link rel="stylesheet" type="text/css" href="style.css">

<!-- Displaying all hotels -->
<div class="container1">
    <div class="row" style="">
        <?php
        $sql = "SELECT * FROM hotel ORDER BY id DESC";
        $result = $conn->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    $name_slug = preg_replace('#[ -]+#', '-', strtolower($row['name']));
                    $region = strtolower($row['region']);
                    $city = strtolower($row['city']);
        ?>
                    <div class="col-4 mb-2">
                        <a class="d-block shadow text-dark" href="hotel.php?id=<?php echo $row['id']; ?>">
                            <img class="w-100" style="height: 300px;" src="assets/hotel_img/<?php echo $region; ?>/<?php echo $city; ?>/<?php echo $name_slug; ?>/<?php echo $row['img']; ?>" alt="<?php echo $row['name']; ?>" />
                            <div class="hotel-list-item-details">
                                <span><?php echo $row['name']; ?></span>
                                <span class="fw-bold">Price : ₵ <?php echo $row['price']; ?></span>
                            </div>
                        </a>
                    </div>
        <?php
            }} else {
                    echo "<h2 style='color:red;'>No Hotels Found</h2>";
                }
            }else {
                echo "Query failed";
            }
        
        ?>
    </div>
</div>

<?php include 'footer.php'; ?>
