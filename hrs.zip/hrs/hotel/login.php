<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- jQuery UI CSS -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/loginstyles.css">
    <link rel="stylesheet" href="styles.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    
    <!-- jQuery UI JS -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <!-- Datepicker Initialization -->
    <script>
        $(function() {
            $("#datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                maxDate: '0',
                yearRange: '1950:2016',
            });
        });
    </script>

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
            max-width: 600px;
        }
        .card {
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .alert {
            margin-bottom: 20px;
        }
        .btn-primary {
            width: 100%;
        }
        .text-center a {
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php
if (isset($_GET['logout']) && $_GET['logout'] == "true") {
    $_SESSION['is_logged_in'] = 'false';
    echo '<script type="text/javascript">window.location = "login.php"</script>';
}
?>
<?php if ($_SESSION['is_logged_in'] != "true") { ?>
<div class="container">
    <div class="text-center">
        <?php if (isset($_SESSION['alert'])) { echo '<div class="alert alert-info">' . $_SESSION['alert'] . '</div>'; $_SESSION['alert'] = ""; } ?>
    </div>

    <div class="card">
        <h3 class="text-center">Enter your details</h3>
        <form action="login_check.php" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <div class="text-center">
            <a href="register.php">Register</a>
            <a href="index.php">Continue as Guest</a>
        </div>
    </div>
</div>
<?php } else {
    echo '<script type="text/javascript">window.location = "index.php"</script>';
} ?>

<!-- Bootstrap JavaScript and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
