<?php
session_start();
require 'mysql_connect.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_POST["email"], $_POST["password"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT id, email, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Checking email and password
    if($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Verify the password
        if ($password == $row['password']) {
            $_SESSION['userid'] = $row['id'];
            $_SESSION['is_logged_in'] = "true";
            $_SESSION["message"] = "Welcome!";

            echo '<script type="text/javascript">
                    window.location = "index.php"
                  </script>';
        } else {
            $_SESSION["message"] = '<p style="color:red;">The email or password is incorrect!</p>';

            echo '<script type="text/javascript">
                    window.location = "login.php"
                  </script>';
        }
    } else {
        $_SESSION["message"] = '<p style="color:red;">The email or password is incorrect!</p>';

        echo '<script type="text/javascript">
                window.location = "login.php"
              </script>';
    }
    $stmt->close();
}
?>
