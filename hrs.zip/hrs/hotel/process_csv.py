import csv

# Path to the full dataset CSV
input_file = 'data.csv'
output_file = 'surprise_data.csv'

with open(input_file, 'r') as csvfile, open(output_file, 'w', newline='') as outfile:
    reader = csv.DictReader(csvfile)
    writer = csv.writer(outfile)
    
    # Write header for the Surprise dataset
    writer.writerow(['user_id', 'hotel_id', 'hotel_rating'])
    
    for row in reader:
        # If rating is not available, use 0 as a placeholder
        rating = row['hotel_rating'] if row['hotel_rating'].isdigit() else '0'
        writer.writerow([row['user_id'], row['hotel_id'], rating])
