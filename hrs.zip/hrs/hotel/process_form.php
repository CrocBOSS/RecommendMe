<?php
include 'mysql_connect.php'; // Ensure this file connects to your MySQL database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $region = $_POST['region'];
    $destination = $_POST['destination'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $guests = $_POST['guests'];
    $room_preferences = $_POST['room_preferences'];
    $budget = $_POST['budget'];
    $price_range = $_POST['price_range'];
    $travel_purpose = $_POST['travel_purpose'];
    $activities = $_POST['activities'];
    $amenities = $_POST['amenities'];

    // SQL to insert data into your database
    $sql = "INSERT INTO user_preferences (region, destination, checkin, checkout, guests, room_preferences, budget, price_range, travel_purpose, activities, amenities) 
            VALUES ('$region', '$destination', '$checkin', '$checkout', '$guests', '$room_preferences', '$budget', '$price_range', '$travel_purpose', '$activities', '$amenities')";

    if ($conn->query($sql) === TRUE) {
        echo "Working on your best fit.. Please hold";

        // Generate CSV file
        $csvFile = 'data.csv';
        $output = fopen($csvFile, 'w');
        fputcsv($output, array('user_id', 'region', 'destination', 'checkin', 'checkout', 'guests', 'room_preferences', 'budget', 'price_range', 'travel_purpose', 'activities', 'amenities', 'hotel_id', 'hotel_name', 'hotel_price', 'facilities', 'hotel_rating'));

        // SQL to select hotels based on region, activities, amenities, and include unrated hotels
        $sql = "SELECT up.*, h.id AS hotel_id, h.name AS hotel_name, h.price AS hotel_price, h.facility AS hotel_facility, r.rating AS hotel_rating 
                FROM user_preferences up
                JOIN hotel h ON up.region = h.region
                LEFT JOIN reviews r ON h.id = r.hotel_id
                WHERE up.region = '$region'
                AND (h.facility LIKE '%$activities%' OR h.facility LIKE '%$amenities%')";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Include hotels with or without ratings
                $rating = isset($row['hotel_rating']) ? $row['hotel_rating'] : 'No Rating Available';
                fputcsv($output, array_merge($row, ['hotel_rating' => $rating]));
            }
        } else {
            // If no hotels match activities or amenities, recommend all hotels in the region
            $sql = "SELECT up.*, h.id AS hotel_id, h.name AS hotel_name, h.price AS hotel_price, h.facility AS hotel_facility, r.rating AS hotel_rating 
                    FROM user_preferences up
                    JOIN hotel h ON up.region = h.region
                    LEFT JOIN reviews r ON h.id = r.hotel_id
                    WHERE up.region = '$region'";

            $result = $conn->query($sql);

            if ($result->num_rows == 1) {
                // Recommend the only hotel available if there's only one hotel in the region
                while($row = $result->fetch_assoc()) {
                    $rating = isset($row['hotel_rating']) ? $row['hotel_rating'] : 'No Rating Available';
                    fputcsv($output, array_merge($row, ['hotel_rating' => $rating]));
                }
            } elseif ($result->num_rows > 0) {
                // Recommend multiple hotels without considering activities/amenities
                while($row = $result->fetch_assoc()) {
                    $rating = isset($row['hotel_rating']) ? $row['hotel_rating'] : 'No Rating Available';
                    fputcsv($output, array_merge($row, ['hotel_rating' => $rating]));
                }
            } else {
                echo "No hotels found in the selected region.";
            }
        }
        fclose($output);

        // Run Python script to process the CSV file and generate a new CSV file
        $pythonPath = '/opt/lampp/htdocs/hrs/re/venv/bin/python3';
        $command = escapeshellcmd("$pythonPath process_csv.py");
        shell_exec($command);

        // Now run the Surprise script on the new CSV file
        $command = escapeshellcmd("$pythonPath recommendation.py");
        $output = shell_exec($command);
        $recommendations = json_decode($output, true);

        // Display recommendations
        echo "<h2>Recommendations:</h2>";
        foreach ($recommendations as $user => $items) {
            echo "User $user:<br>";
            foreach ($items as $item) {
                echo "  Hotel ID {$item[0]} with predicted rating {$item[1]}<br>";
            }
        }

        // Delete user preferences after processing
        $deleteSql = "DELETE FROM user_preferences WHERE region = '$region' AND destination = '$destination' AND checkin = '$checkin' AND checkout = '$checkout'";
        if ($conn->query($deleteSql) === TRUE) {
            // Preferences deleted successfully
        } else {
            echo "Error deleting previous preferences: " . $conn->error;
        }

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
