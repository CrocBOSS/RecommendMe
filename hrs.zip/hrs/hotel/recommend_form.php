<?php include 'header.php';
 require 'mysql_connect.php';
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<div class="container my-5">
    <h1 class="text-center mb-4">Hotel Recommendation System</h1>
    
    <div class="card p-4">
        <h2 class="card-title text-center font-weight-bold">RECOMMEND HOTELS</h2>

        <form class="serachs-form" action="process_form.php" method="post">
            <!-- Trip Information -->
            <div class="form-group">
                <label for="region">Region:</label>
                <select id="region" name="region" class="form-control" required>
                    <option value="">Select a region</option>
                    <option value="greater-accra">Greater Accra</option>
                    <option value="ashanti">Ashanti</option>
                    <option value="central">Central</option>
                    <option value="eastern">Eastern</option>
                    <option value="northern">Northern</option>
                    <option value="upper-east">Upper East</option>
                    <option value="upper-west">Upper West</option>
                    <option value="volta">Volta</option>
                    <option value="western">Western</option>
                    <option value="western-north">Western North</option>
                    <option value="savannah">Savannah</option>
                    <option value="oti">Oti</option>
                    <option value="brong-ahafo">Brong-Ahafo</option>
                    <option value="ahafo">Ahafo</option>
                    <option value="bono-east">Bono East</option>
                    <option value="bono">Bono</option>
                    <option value="north-east">North East</option>
                </select>
            </div>

            <div class="form-group">
                <label for="destination">Destination:</label>
                <input type="text" id="destination" name="destination" class="form-control" placeholder="Enter your travel destination" required>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="checkin">Check-in Date:</label>
                    <input type="date" id="checkin" name="checkin" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="checkout">Check-out Date:</label>
                    <input type="date" id="checkout" name="checkout" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label for="guests">Number of Guests:</label>
                <input type="number" id="guests" name="guests" class="form-control" min="1" placeholder="Enter number of guests" required>
            </div>

            <div class="form-group">
                <label for="room_preferences">Room Preferences:</label>
                <input type="text" id="room_preferences" name="room_preferences" class="form-control" placeholder="Specify your room preferences">
            </div>

            <!-- Budget and Spending Preferences -->
            <div class="form-group">
                <label for="budget">Max Budget per Night:</label>
                <input type="number" id="budget" name="budget" class="form-control" placeholder="Enter your maximum budget per night" required>
            </div>

            <!-- Travel Purpose -->
            <div class="form-group">
                <label for="travel_purpose">Reason for Travel:</label>
                <input type="text" id="travel_purpose" name="travel_purpose" class="form-control" placeholder="Enter the reason for your travel (e.g., business, vacation)">
            </div>

            <div class="form-group">
                <label for="activities">Activities of Interest:</label>
                <textarea id="activities" name="activities" class="form-control" placeholder="List activities you're interested in (e.g., sightseeing, shopping)"></textarea>
            </div>

            <!-- Additional Preferences -->
            <div class="form-group">
                <label for="amenities">Amenities Preferences:</label>
                <textarea id="amenities" name="amenities" class="form-control" placeholder="List preferred amenities (e.g., free Wi-Fi, pool, gym)"></textarea>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Get Recommendations</button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>


