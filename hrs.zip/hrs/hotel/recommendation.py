from surprise import Dataset, Reader, SVD
from surprise.model_selection import train_test_split
from surprise import accuracy
import json
import pandas as pd

# Load the data with additional columns
def load_data(file_path):
    # Load CSV into pandas first to manage missing ratings and non-rating info
    df = pd.read_csv(file_path)

    # Fill missing ratings with a neutral value (e.g., median rating or 3)
    df['hotel_rating'].fillna(3, inplace=True)

    # Prepare data for Surprise with only necessary columns (user, item, rating)
    df_surprise = df[['user_id', 'hotel_id', 'hotel_rating']]

    # Use Surprise Reader to load the data for collaborative filtering
    reader = Reader(rating_scale=(1, 5))
    data = Dataset.load_from_df(df_surprise, reader)
    return data, df  # Return both the Surprise dataset and the full DataFrame

# Train and evaluate the model
def train_model(data):
    trainset, testset = train_test_split(data, test_size=0.25)
    algo = SVD()
    algo.fit(trainset)

    # Predict and evaluate
    predictions = algo.test(testset)
    accuracy.rmse(predictions)
    return algo

# Make recommendations
def get_top_n(predictions, n=10):
    top_n = {}
    for uid, iid, true_r, est, _ in predictions:
        if not top_n.get(uid):
            top_n[uid] = []
        top_n[uid].append((iid, est))

    for uid, user_ratings in top_n.items():
        user_ratings.sort(key=lambda x: x[1], reverse=True)
        top_n[uid] = user_ratings[:n]

    return top_n

# Hybrid: Filter hotels based on user preferences (activities, amenities)
def filter_hotels_by_preferences(df, user_activities, user_amenities, region):
    # Filter hotels based on region, activities, and amenities
    filtered_hotels = df[
        (df['region'] == region) & 
        (df['hotel_facility'].str.contains(user_activities, case=False, na=False) | 
         df['hotel_facility'].str.contains(user_amenities, case=False, na=False))
    ]
    
    return filtered_hotels[['hotel_id', 'hotel_name', 'hotel_price', 'hotel_rating']]

# Main execution
if __name__ == "__main__":
    file_path = 'surprise_data.csv'  # Path to your data file
    user_preferences = {  # Mock data for user preferences, could be passed dynamically
        "activities": "swimming",
        "amenities": "wifi",
        "region": "Greater Accra"
    }

    # Load data and full DataFrame
    data, df_full = load_data(file_path)

    # Train the recommendation model
    algo = train_model(data)

    # Predict for all users and items
    testset = data.build_full_trainset().build_testset()
    predictions = algo.test(testset)

    # Get top N recommendations based on collaborative filtering
    top_n = get_top_n(predictions, n=10)

    # Filter hotels based on user preferences (activities, amenities)
    recommended_hotels = filter_hotels_by_preferences(df_full, user_preferences['activities'], user_preferences['amenities'], user_preferences['region'])

    # Combine the recommendations with preference-filtered hotels
    print("Collaborative Filtering Recommendations:")
    print(json.dumps(top_n, indent=4))  # Print CF-based recommendations as JSON

    print("\nPreference-Filtered Hotels:")
    print(recommended_hotels.to_dict(orient='records'))  # Print preference-based filtered hotels
