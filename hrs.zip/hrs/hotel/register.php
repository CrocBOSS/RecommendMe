<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <!-- Custom CSS (optional) -->
  <style>
    body {
      font-family: 'Roboto', sans-serif;
      background-color: #f8f9fa;
    }
    .container {
      margin-top: 50px;
      max-width: 600px;
    }
    .card {
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-group label {
      font-weight: bold;
    }
    .alert {
      margin-bottom: 20px;
    }
    .btn-primary {
      width: 100%;
    }
    .text-center a {
      display: block;
      margin-top: 10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="text-center">
    <?php if(isset($_SESSION['alert'])) { echo '<div class="alert alert-info">' . $_SESSION['alert'] . '</div>'; $_SESSION['alert'] = ""; } ?>
  </div>

  <div class="card">
    <h3 class="text-center">Register</h3>

    <form action="registernow.php" method="post">
      <!-- Basic Information -->
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name" required>
      </div>

      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email address" required>
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Create a password" required>
      </div>

      <!-- Demographic Information -->
      <div class="form-group">
        <label for="dob">Date of Birth:</label>
        <input type="date" class="form-control" id="dob" name="dob" required>
      </div>

      <div class="form-group">
        <label for="gender">Gender:</label>
        <select class="form-control" id="gender" name="gender">
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </div>

      <!-- Preferences and Interests -->
      <div class="form-group">
        <label for="travel_preferences">Travel Preferences:</label>
        <textarea class="form-control" id="travel_preferences" name="travel_preferences" placeholder="Describe your travel preferences (e.g., luxury, budget, etc.)"></textarea>
      </div>

      <div class="form-group">
        <label for="frequent_locations">Frequent Travel Locations:</label>
        <input type="text" class="form-control" id="frequent_locations" name="frequent_locations" placeholder="Enter cities or regions you often visit">
      </div>

      <!-- Contact Information -->
      <div class="form-group">
        <label for="phone">Phone Number:</label>
        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter your phone number">
      </div>

      <button type="submit" class="btn btn-primary">Create Account</button>
    </form>

    <div class="text-center">
      <a href="login.php">Login</a>
      <a href="index.php">Continue as Guest</a>
    </div>
  </div>
</div>

<!-- Bootstrap JavaScript and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
