<?php
session_start();
require 'mysql_connect.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/* Registering user */
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$travel_preferences = $_POST['travel_preferences'];
$frequent_locations = $_POST['frequent_locations'];
$phone = $_POST['phone'];

if ($email == "admin@example.com") {
    $_SESSION['alert'] = "You are not allowed to use 'admin@example.com' as an email.";
    header("Location: register.php");
    die();
}

$sql1 = "SELECT email FROM users WHERE email = '$email'";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    $_SESSION['alert'] = "Email already exists. Please use a different email.";
    header("Location: register.php");
    die();
}

//$passwordHash = password_hash($password, PASSWORD_BCRYPT);

$sql = "INSERT INTO users (name, email, password, dob, gender, travel_preferences, frequent_locations, phone) 
        VALUES ('$name', '$email', '$password', '$dob', '$gender', '$travel_preferences', '$frequent_locations', '$phone')";

if ($conn->query($sql) === TRUE) {
    $_SESSION['alert'] = "Registration successful. Please log in.";
    header("Location: login.php");
} else {
    $_SESSION['alert'] = "Error: " . $conn->error;
    header("Location: register.php");
}
?>
