<?php
session_start();
require 'mysql_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize user input
    $hotel_id = isset($_POST['hotelid']) ? mysqli_real_escape_string($conn, $_POST['hotelid']) : '';
    $rating = isset($_POST['rating']) ? mysqli_real_escape_string($conn, $_POST['rating']) : '';
    $reviews = isset($_POST['reviews']) ? mysqli_real_escape_string($conn, $_POST['reviews']) : '';
    $username = isset($_POST['username']) ? mysqli_real_escape_string($conn, $_POST['username']) : '';

    // Check if the rating is provided
    if (!empty($rating)) {
        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO reviews (hotel_id, rating, reviews, username) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siss", $hotel_id, $rating, $reviews, $username);

        // Execute the statement
        if ($stmt->execute()) {
            header("Location: hotel.php?id=$hotel_id");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "<script>alert('Please select a rating.'); window.history.back();</script>";
    }
} else {
    echo "Invalid request method.";
}

// Close the database connection
$conn->close();
?>
