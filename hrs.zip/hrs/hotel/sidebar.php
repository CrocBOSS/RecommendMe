<div style="width:10%; background:#34495e; min-height: 1000px; color:white; padding:50px; float:left;">
    <a style="color:white; background:red; display: block; width:100%; padding:5px 10px; margin-bottom: 10px;" href="add-new-hotel.php">Add New Hotel</a>
    <a style="color:white; background:red; display: block; width:100%; padding:5px 10px;" href="all-hotel.php">All Hotels</a>
</div>
