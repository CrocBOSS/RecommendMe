<?php
session_start();
require 'mysql_connect.php';

// Enable error reporting for debugging purposes
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Retrieve and sanitize user input
$id = mysqli_real_escape_string($conn, $_POST['id']);
$name = mysqli_real_escape_string($conn, $_POST['name']);
$price = mysqli_real_escape_string($conn, $_POST['price']);
$pricemax = mysqli_real_escape_string($conn, $_POST['pricemax']);
$description = mysqli_real_escape_string($conn, $_POST['description']);
$facility = mysqli_real_escape_string($conn, $_POST['facility']);
$new_region = mysqli_real_escape_string($conn, $_POST['region']);
$city = mysqli_real_escape_string($conn, $_POST['city']);

// Fetch the original region and image data from the database
$sql_fetch = "SELECT region, img FROM hotel WHERE id = $id";
$result = $conn->query($sql_fetch);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $original_region = $row['region'];
    $original_img = $row['img'];
} else {
    die("Hotel not found.");
}

// Generate the name slug
$name_slug = preg_replace('#[ -]+#', '-', strtolower($name));

// Set target directory based on original or new region
$target_dir = "assets/hotel_img/" . strtolower($original_region) . "/" . $name_slug;

// Create directory if it doesn't exist
if (!file_exists($target_dir)) {
    if (!mkdir($target_dir, 0777, true)) {
        die("Failed to create directories...");
    }
}

// Handle file upload and move it to the correct folder
$img = $_FILES['file']['name'];

if (!empty($_FILES['file']['tmp_name'])) {
    // New image uploaded
    $target_file = $target_dir . "/" . basename($img);
    move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
} else {
    // No new image, keep the old one
    $img = $original_img;
}

// If the region has changed, move the image to the new region's folder
if ($new_region != $original_region) {
    $new_target_dir = "assets/hotel_img/" . strtolower($new_region) . "/" . $name_slug;

    if (!file_exists($new_target_dir)) {
        if (!mkdir($new_target_dir, 0777, true)) {
            die("Failed to create directories...");
        }
    }

    $new_target_file = $new_target_dir . "/" . basename($img);

    // Move the existing image to the new location
    if (!rename($target_dir . "/" . $img, $new_target_file)) {
        die("Failed to move image to new folder.");
    }

    // Update the directory path
    $target_file = $new_target_file;
}

// Update the hotel information in the database
$sql = "UPDATE hotel SET 
    name='$name', 
    price='$price', 
    pricemax='$pricemax', 
    description='$description', 
    facility='$facility', 
    region='$new_region', 
    city='$city', 
    img='$img' 
    WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: all-hotel.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
